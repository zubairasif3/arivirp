<template>
  <div>
    <!-- providers modal-  data-target="#providersModal"  -->
    <div class="modal fade" id="providersModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title translate-text" data-i18n="game-providers">Game Providers</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <nav>
              <div class="nav nav-tabs nav-tabs-pills" role="tablist">
                <button class="nav-link active translate-text" data-i18n="slots" id="p-sports-tab" data-toggle="tab" data-target="#c-slot-tab" type="button" role="tab" aria-controls="p-slot-tab" aria-selected="true">Slots</button>
                <button class="nav-link translate-text" data-i18n="live-casino" id="p-livecasino-tab" data-toggle="tab" data-target="#c-livecasino-tab" type="button" role="tab" aria-controls="p-livecasino-tab" aria-selected="false">Live Casino</button>
                <button class="nav-link translate-text" data-i18n="slots" id="p-sports-tab" data-toggle="tab" data-target="#c-sports-tab" type="button" role="tab" aria-controls="p-sports-tab" aria-selected="false">Sports</button>
                <button class="nav-link translate-text" data-i18n="cockfight" id="p-cockfight-tab" data-toggle="tab" data-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Cockfight</button>
                <button class="nav-link translate-text" data-i18n="fishing" id="p-fishing-tab" data-toggle="tab" data-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Fishing</button>
                <button class="nav-link translate-text" data-i18n="arcade" id="p-arcade-tab" data-toggle="tab" data-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Arcade</button>
                <button class="nav-link translate-text" data-i18n="lottery" id="p-lottery-tab" data-toggle="tab" data-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">DD/Lottery</button>
              </div>
            </nav>
            <div class="tab-content tab-pills-content">
              <div class="tab-pane fade show active" id="c-slot-tab" role="tabpanel" aria-labelledby="slot-tab">
                <div class="row">
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/918.png" alt="">
                      <span class="text-uppercase">918 kiss</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/918-kaya.png" alt="">
                      <span class="text-uppercase">918 kaya</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/all-bet.png" alt="">
                      <span class="text-uppercase">all bet</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/ag.png" alt="">
                      <span class="text-uppercase">asia gaming</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/xe88.png" alt="">
                      <span class="text-uppercase">xe 88</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/wm-casino.png" alt="">
                      <span class="text-uppercase">wm casino</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/mega888.png" alt="">
                      <span class="text-uppercase">mega 888</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/m8bet.png" alt="">
                      <span class="text-uppercase">m8bet</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="c-sports-tab" role="tabpanel" aria-labelledby="sports-tab">
                <div class="row">
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/xe88.png" alt="">
                      <span class="text-uppercase">xe 88</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/wm-casino.png" alt="">
                      <span class="text-uppercase">wm casino</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/mega888.png" alt="">
                      <span class="text-uppercase">mega 888</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/m8bet.png" alt="">
                      <span class="text-uppercase">m8bet</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/918.png" alt="">
                      <span class="text-uppercase">918 kiss</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/918-kaya.png" alt="">
                      <span class="text-uppercase">918 kaya</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/all-bet.png" alt="">
                      <span class="text-uppercase">all bet</span>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="single-modal-provider">
                      <img src="../images/modal-provder/ag.png" alt="">
                      <span class="text-uppercase">asia gaming</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="p-livecasino-tab" role="tabpanel" aria-labelledby="livecasno-tab">Live Casino Tabs</div>
            </div>

            <nav aria-label="page navigation">
              <ul class="pagination pagination-lg justify-content-center">
                <li class="page-item">
                  <a class="page-link" href="javascript:" tabindex="-1">
                    <span aria-hidden="true">&lsaquo;</span>
                  </a>
                </li>
                <li class="page-item active"><a class="page-link" href="javascript:">1</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">2</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">3</a></li>
                <li class="page-item">
                  <a class="page-link" href="javascript:">
                    <span aria-hidden="true">&rsaquo;</span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>

    <!-- bonus and rewards modal-  data-target="#bonusRewardsModal"  -->
    <div class="modal fade" id="bonusRewardsModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Bonus and Rewards</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <nav>
              <div class="nav nav-tabs nav-tabs-pills nav-tabs-pills-bonus-and-rewards" role="tablist">
                <button class="nav-link active" id="br-active-bonus-tab" data-toggle="tab" data-target="#brc-active-bonus-tab" type="button" role="tab" aria-controls="br-active-bonus-tab" aria-selected="true">Active Bonus</button>
                <button class="nav-link" id="br-available-tab" data-toggle="tab" data-target="#brc-available-tab" type="button" role="tab" aria-controls="br-available-tab" aria-selected="false">Available bonus</button>
                <button class="nav-link" id="br-bonus-history-tab" data-toggle="tab" data-target="#brc-bonus-history-tab" type="button" role="tab" aria-controls="br-bonus-history-tab" aria-selected="false">Bonus History</button>
              </div>
            </nav>
            <div class="tab-content tab-pills-content mb-4">
              <div class="tab-pane fade show active" id="brc-active-bonus-tab" role="tabpanel" aria-labelledby="br-active-bonus-tab">
                <table class="table table-borderless text-white table-casino00">
                  <thead>
                    <tr>
                      <th>Bonus Name</th>
                      <th>Received Amount</th>
                      <th>Wager</th>
                      <th>Promo Period</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td>Welcome</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td>Reload</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td>Rebate</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td>Cashback</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td>Free Spin</td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade" id="brc-available-tab" role="tabpanel" aria-labelledby="br-available-tab">
                <p class="text-center">available bonus content coming soon</p>
              </div>
              <div class="tab-pane fade" id="brc-bonus-history-tab" role="tabpanel" aria-labelledby="br-bonus-history-tab">
                <p class="text-center">bonus history  content coming soon</p>
              </div>
            </div>

            <nav aria-label="page navigation">
              <ul class="pagination pagination-lg justify-content-center">
                <li class="page-item">
                  <a class="page-link" href="javascript:" tabindex="-1">
                    <span aria-hidden="true">&lsaquo;</span>Previous
                  </a>
                </li>
                <li class="page-item active"><a class="page-link" href="javascript:">1</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">2</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">3</a></li>
                <li class="page-item">
                  <a class="page-link" href="javascript:">
                    Next<span aria-hidden="true">&rsaquo;</span>
                  </a>
                </li>
              </ul>
            </nav>

            <div class="d-flex align-items-center justify-content-center mt-4 mb-3">
              <button type="button" class="btn btn-secondary border-gray mr-2 font18 text-uppercase mw185 h55" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary btn-primary-md ml-2 font18 text-uppercase mw185 h55">Check Bonuses</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- history modal-  data-target="#traansctionHistoryModal"  -->
    <div class="modal fade" id="traansctionHistoryModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title translate-text" data-i18n="transaction-history">Transactions History</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <nav>
              <div class="nav nav-tabs nav-tabs-pills nav-tabs-pills-bonus-and-rewards" role="tablist">
                <button class="nav-link translate-html" data-i18n="deposit-history" id="th-deposit-history-tab" data-toggle="tab" data-target="#thc-deposit-history-tab" type="button" role="tab" aria-controls="th-deposit-history-tab" aria-selected="false">Deposit History</button>
                <button class="nav-link active translate-html" data-i18n="withdrawal-history"  id="th-withdrawal-history-tab" data-toggle="tab" data-target="#thc-withdrawal-history-tab" type="button" role="tab" aria-controls="th-withdrawal-history-tab" aria-selected="true">Withdrawal History</button>
                <button class="nav-link translate-html" data-i18n="bonus-history" id="th-bonus-history-tab" data-toggle="tab" data-target="#thc-bonus-history-tab" type="button" role="tab" aria-controls="th-bonus-history-tab" aria-selected="false">Bonus History</button>
                <button class="nav-link translate-html" data-i18n="game-history" id="th-game-history-tab" data-toggle="tab" data-target="#thc-game-history-tab" type="button" role="tab" aria-controls="th-game-history-tab" aria-selected="false">Game History</button>
              </div>
            </nav>
            <div class="tab-content tab-pills-content mb-4">
              <div class="tab-pane fade" id="thc-deposit-history-tab" role="tabpanel" aria-labelledby="thc-deposit-history-tab">
                <table class="table table-borderless text-white table-casino00">
                  <thead>
                    <tr>
                      <th class="translate-text" data-i18n="amount">Amount</th>
                      <th class="translate-text" data-i18n="transaction-id">Transaction ID</th>
                      <th class="translate-text" data-i18n="payment-method">Payment Method</th>
                      <th class="translate-text" data-i18n="date-time">Date/Time</th>
                      <th class="translate-text" data-i18n="status">Status</th>
                      <th class="translate-text" data-i18n="turnover">Turnover/Target</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                    <tr>
                      <td class="align-middle">
                        <span class="d-block font15 text-uppercase">100.0000000 BTC</span>
                        <span class="d-block font12 font-weight-normal text-gray">100.0000000 BTC</span>
                      </td>
                      <td class="align-middle">
                        <span class="d-block font15 text-uppercase font-weight-normal">0000001-080808</span>
                      </td>
                      <td class="align-middle">
                        <span class="d-block font15 text-uppercase font-weight-normal">Visa</span>
                      </td>
                      <td class="align-middle">
                        <span class="d-block font15 text-white font-weight-normal">2022-08-08</span>
                      </td>
                      <td class="align-middle">
                        <span class="d-block font15 text-gold text-capitalize font-weight-normal">Successful</span>
                      </td>
                      <td class="align-middle">
                        <span class="d-block font15 text-capitalize font-weight-normal">2022-08-08</span>
                      </td>
                    </tr>
                    <tr class="spacer">
                      <td colspan="5"></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade show active" id="thc-withdrawal-history-tab" role="tabpanel" aria-labelledby=thc-withdrawal-history-tab">
                <table class="table table-borderless text-white table-casino00">
                  <thead>
                  <tr>
                    <th class="translate-text" data-i18n="amount">Amount</th>
                    <th class="translate-text" data-i18n="transaction-id">Transaction ID</th>
                    <th class="translate-text" data-i18n="payment-method">Payment Method</th>
                    <th class="translate-text" data-i18n="date-time">Date/Time</th>
                    <th class="translate-text" data-i18n="status">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  <tr>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase">100.0000000 BTC</span>
                      <span class="d-block font12 font-weight-normal text-gray">100.0000000 BTC</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">0000001-080808</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">Visa</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-white font-weight-normal">2022-08-08</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-gold text-capitalize font-weight-normal">Successful</span>
                    </td>
                  </tr>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade" id="thc-bonus-history-tab" role="tabpanel" aria-labelledby="thc-bonus-history-tab">
                <table class="table table-borderless text-white table-casino00">
                  <thead>
                  <tr>
                    <th class="translate-text" data-i18n="amount">Amount</th>
                    <th class="translate-text" data-i18n="transaction-id">Transaction ID</th>
                    <th class="translate-text" data-i18n="bonus">Bonus</th>
                    <th class="translate-text" data-i18n="date-time">Date/Time</th>
                    <th class="translate-text" data-i18n="status">Status</th>
                    <th class="translate-text" data-i18n="turnover">Turnover/Target</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  <tr>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase">100.0000000 BTC</span>
                      <span class="d-block font12 font-weight-normal text-gray">100.0000000 BTC</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">0000001-080808</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">10</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-white font-weight-normal">2022-08-08</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-gold text-capitalize font-weight-normal">Successful</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-capitalize font-weight-normal">2022-08-08</span>
                    </td>
                  </tr>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade" id="thc-game-history-tab" role="tabpanel" aria-labelledby="thc-game-history-tab">
                <table class="table table-borderless text-white table-casino00">
                  <thead>
                  <tr>
                    <th class="translate-text" data-i18n="date-time">Date/Time</th>
                    <th class="translate-text" data-i18n="transaction-id">Transaction ID</th>
                    <th class="translate-text" data-i18n="provider">Provider</th>
                    <th class="translate-text" data-i18n="stake">Stake</th>
                    <th class="translate-text" data-i18n="payout">Payout</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  <tr>
                    <td class="align-middle">
                      <span class="d-block font15 font-weight-normal">2022-08-08</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">0000001-080808</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-uppercase font-weight-normal">pt</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-capitalize font-weight-normal">10</span>
                    </td>
                    <td class="align-middle">
                      <span class="d-block font15 text-capitalize font-weight-normal">10</span>
                    </td>
                  </tr>
                  <tr class="spacer">
                    <td colspan="5"></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <nav aria-label="page navigation">
              <ul class="pagination pagination-lg justify-content-center">
                <li class="page-item">
                  <a class="page-link" href="javascript:" tabindex="-1">
                    <span aria-hidden="true">&lsaquo;</span>
                  </a>
                </li>
                <li class="page-item active"><a class="page-link" href="javascript:">1</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">2</a></li>
                <li class="page-item"><a class="page-link" href="javascript:">3</a></li>
                <li class="page-item">
                  <a class="page-link" href="javascript:">
                    <span aria-hidden="true">&rsaquo;</span>
                  </a>
                </li>
              </ul>
            </nav>

<!--            <div class="d-flex align-items-center justify-content-center mt-4 mb-3">-->
<!--              <button type="button" class="btn btn-secondary border-gray mr-2 font18 text-uppercase mw185 h55" data-dismiss="modal">Close</button>-->
<!--              <button type="button" class="btn btn-primary btn-primary-md ml-2 font18 text-uppercase mw185 h55">Deposit</button>-->
<!--            </div>-->
          </div>
        </div>
      </div>
    </div>

    <!-- deposit modal-  data-target="#depositModal"  -->
    <div class="modal fade" id="depositModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title translate-text" data-i18n="deposit">Deposit</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
						<nav>
							<div class="nav nav-tabs nav-tabs-pills nav-tabs-pills-deposit" role="tablist">
								<button class="nav-link text-capitalize active translate-html" data-i18n="crypto"  id="d-crypto" data-toggle="tab" data-target="#dc-crypto" type="button" aria-selected="true">Crypto</button>
								<button class="nav-link text-capitalize translate-html" data-i18n="online-banking"  id="d-online-banking" data-toggle="tab" data-target="#dc-online-banking" type="button" aria-selected="true">Online Banking</button>
								<button class="nav-link text-capitalize translate-html" data-i18n="debit-credit-card"  id="d-card" data-toggle="tab" data-target="#dc-card" type="button" aria-selected="true">Credit/Debit Card</button>
								<button class="nav-link text-capitalize translate-html" data-i18n="qr-pay"  id="d-qrpay" data-toggle="tab" data-target="#dc-qrpay" type="button" aria-selected="true">QR Pay</button>
							</div>
						</nav>
            <div class="tab-content tab-pills-content">
							<!-- deposit: crypto -->
              <div class="tab-pane fade show active" id="dc-crypto" role="tabpanel">
								<form action="/">
									<div class="form-group">
										<select name="currency" id="currency" class="form-control">
											<option value="" class="translate-text" data-i18n="select-cryptocurrency" >Select Cryptocurrency</option>
										</select>
									</div>
									<div class="form-group mb-0">
										<select name="network" id="network" class="form-control">
											<option value="" class="translate-text" data-i18n="select-network">Select Network</option>
										</select>
									</div>
									<div class="mt-2 mb-2 text-gold font-weight-bold translate-text" data-i18n="usdt-deposit-address">USDT Deposit Address</div>
									<div class="form-group">
										<div class="input-group">
											<input type="text" id="deposit_code" class="form-control" aria-label="deposit code" aria-describedby="deposit code" value="31zgcxhLT15vFYWX7PjsFegAN1HAh3gfD4">
											<div class="input-group-append">
												<button class="btn btn-copy btn-copy-clipboard text-uppercase translate-html" data-i18n="copy" data-target="deposit_code" type="button">Copy</button>
											</div>
										</div>
									</div>
                  <div class="form-group">
                    <div class="deposit-qr-wrap d-flex flex-column justify-content-center p-4">
											<div class="qr-img mt-2 mx-auto">
												<img src="../images/qr-sample.png" alt="depsit qr" class="d-block mb-2">
												<span class="text-uppercase text-white text-center d-block font-weight-bold font18 translate-text" data-i18n="scan-qr-code">Scan qr code</span>
											</div>
                      <div class="mt-4 text-center px-4">
                        <p class="font15 text-white font-italic mb-0 translate-text" data-i18n="ensure-note">Ensure the network you choose to deposit matches the
													withdrawal network, otherwise your assets may be lost.</p>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="promo-code" name="promo_code" id="promo_code" placeholder="Promo Code">
                  </div>
                  <div class="form-group">
                    <p class="font-weight-bold font15 translate-text" data-i18n="select-bonus">Select Bonus</p>
                    <div class="deposit-bonus-wrap">
                      <div class="bonus-list active">
                        <label for="bonus1">
                          <input type="radio" name="bonus" id="bonus1">
                          <span class="box"></span>
													<img src="../images/bonus1.png" alt="">
                        </label>
                      </div>
											<div class="bonus-list">
												<label for="bonus2">
													<input type="radio" name="bonus" id="bonus2">
													<span class="box"></span>
													<img src="../images/bonus2.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus3">
													<input type="radio" name="bonus" id="bonus3">
													<span class="box"></span>
													<img src="../images/bonus3.png" alt="">
												</label>
											</div>
                    </div>
                  </div>
									<div class="d-flex align-items-center justify-content-center mt-5 mb-4">
										<button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="deposit">Deposit</button>
									</div>
                </form>
              </div>
              
							<!-- deposit: online banking -->
							<div class="tab-pane fade" id="dc-online-banking" role="tabpanel">
								<form action="/">
									<div class="form-group">
										<select name="bank" id="bank" class="form-control">
											<option value="" class="translate-text" data-i18n="select-bank" >Select Bank</option>
										</select>
									</div>
									<div class="form-group amt-group mb-0">
										<input type="text" name="amount" id="amount" class="form-control translate-placeholder" data-i18n="deposit-amount" placeholder="Deposit Amount" />
										<span class="text-gold font-weight-bold">IDR</span>
									</div>
									<div class="mt-2 mb-2 text-gold font-weight-bold font-italic">
                    <span class="translate-text" data-i18n="transaction-limit">Transaction Limit</span> 50.000 - 100.000.000 IDR
                  </div>
									<div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="note" name="note" id="note" placeholder=Note">
									</div>
									<div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="promo-code" name="promo_code" id="promo_code" placeholder="Promo Code">
									</div>
									<div class="form-group">
										<p class="font-weight-bold font15 translate-text" data-i18n="select-bonus">Select Bonus</p>
										<div class="deposit-bonus-wrap">
											<div class="bonus-list active">
												<label for="bonus1">
													<input type="radio" name="bonus" id="bonus1">
													<span class="box"></span>
													<img src="../images/bonus1.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus2">
													<input type="radio" name="bonus" id="bonus2">
													<span class="box"></span>
													<img src="../images/bonus2.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus3">
													<input type="radio" name="bonus" id="bonus3">
													<span class="box"></span>
													<img src="../images/bonus3.png" alt="">
												</label>
											</div>
										</div>
									</div>
                  <div class="form-group">
										<p class="font15 text-white font-weight-bold mb-1 translate-text" data-i18n="actual-amount">Actual Amount</p>
                  </div>
									<div class="d-flex align-items-center justify-content-center mt-5 mb-4">
										<button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="deposit">Deposit</button>
									</div>
								</form>
							</div>
              
							<!-- deposit: debit credit card -->
							<div class="tab-pane fade" id="dc-card" role="tabpanel">
								<form action="/">
                  <div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="cc-number" placeholder="Credit/Debit Card Number">
                  </div>
									<div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="cc-name" placeholder="Name On Card">
									</div>
                  <div class="form-group">
                    <p class="text-white mb-1 translate-text" data-i18n="cc-exp">Expiration Date</p>
                    <div class="form-row cc-date">
                      <div class="form-group col-6 mb-0 position-relative">
                        <select class="form-control">
													<option value="01">01</option>
													<option value="02">02</option>
													<option value="03">03</option>
													<option value="04">05</option>
                        </select>
                        <span class="txt translate-text" data-i18n="month">Month</span>
                      </div>
                      <div class="form-group col-6 mb-0 position-relative">
												<select class="form-control">
													<option value="2023">2023</option>
													<option value="2022">2022</option>
													<option value="2021">2021</option>
													<option value="2020">2020</option>
												</select>
												<span class="txt translate-text" data-i18n="year">Year</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="cc-cvv" placeholder="CVC/CVV">
                  </div>
									<div class="form-group amt-group mb-0">
										<input type="text" name="amount" id="amount" class="form-control translate-placeholder" data-i18n="deposit-amount" placeholder="Deposit Amount" />
										<span class="text-gold font-weight-bold">IDR</span>
									</div>
									<div class="mt-2 mb-2 text-gold font-weight-bold font-italic">
										<span class="translate-text" data-i18n="transaction-limit">Transaction Limit</span> 50.000 - 100.000.000 IDR
                  </div>
									<div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="promo-code" name="promo_code" id="promo_code" placeholder="Promo Code">
									</div>
									<div class="form-group">
										<p class="font-weight-bold font15 translate-text" data-i18n="select-bonus">Select Bonus</p>
										<div class="deposit-bonus-wrap">
											<div class="bonus-list active">
												<label for="bonus1">
													<input type="radio" name="bonus" id="bonus1">
													<span class="box"></span>
													<img src="../images/bonus1.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus2">
													<input type="radio" name="bonus" id="bonus2">
													<span class="box"></span>
													<img src="../images/bonus2.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus3">
													<input type="radio" name="bonus" id="bonus3">
													<span class="box"></span>
													<img src="../images/bonus3.png" alt="">
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<p class="font15 text-white font-weight-bold mb-1 translate-text" data-i18n="actual-amount">Actual Amount</p>
										<p class="font18 text-gold font-weight-bold mb-0">100.000.000</p>
									</div>
									<div class="d-flex align-items-center justify-content-center mt-5 mb-4">
										<button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="deposit">Deposit</button>
									</div>
								</form>
							</div>
              
							<!-- deposit: qr-pay -->
							<div class="tab-pane fade" id="dc-qrpay" role="tabpanel">
								<form action="/">
									<div class="form-group">
										<select name="bank" id="bank" class="form-control">
											<option value="" class="translate-text" data-i18n="select-method">Select Method</option>
										</select>
									</div>
									<div class="form-group amt-group mb-0">
										<input type="text" name="amount" id="amount" class="form-control translate-placeholder" data-i18n="deposit-amount" placeholder="Deposit Amount" />
										<span class="text-gold font-weight-bold">IDR</span>
									</div>
									<div class="mt-2 mb-2 text-gold font-weight-bold font-italic">
										<span class="translate-text" data-i18n="transaction-limit">Transaction Limit</span> 50.000 - 100.000.000 IDR
                  </div>
									<div class="form-group">
										<input type="text" class="form-control translate-placeholder" data-i18n="promo-code" name="promo_code" id="promo_code" placeholder="Promo Code">
									</div>
									<div class="form-group">
										<p class="font-weight-bold font15 translate-text" data-i18n="select-bonus">Select Bonus</p>
										<div class="deposit-bonus-wrap">
											<div class="bonus-list active">
												<label for="bonus1">
													<input type="radio" name="bonus" id="bonus1">
													<span class="box"></span>
													<img src="../images/bonus1.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus2">
													<input type="radio" name="bonus" id="bonus2">
													<span class="box"></span>
													<img src="../images/bonus2.png" alt="">
												</label>
											</div>
											<div class="bonus-list">
												<label for="bonus3">
													<input type="radio" name="bonus" id="bonus3">
													<span class="box"></span>
													<img src="../images/bonus3.png" alt="">
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<p class="font15 text-white font-weight-bold mb-1 translate-text" data-i18n="actual-amount">Actual Amount</p>
										<p class="font18 text-gold font-weight-bold mb-0">100.000.000</p>
									</div>
									<div class="d-flex align-items-center justify-content-center mt-5 mb-4">
										<button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="deposit">Deposit</button>
									</div>
								</form>
							</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- withdrawal modal-  data-target="#withdrawModal"  -->
    <div class="modal fade" id="withdrawModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"> <span class="translate-text" data-i18n="widthraw-s">Withdraw</span> </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <nav>
              <div class="nav nav-tabs nav-tabs-pills nav-tabs-pills-widthdaw" role="tablist">
                <button class="nav-link text-capitalize active translate-html" data-i18n="bank-account" id="w-bank-account" data-toggle="tab" data-target="#wc-bank-account" type="button" role="tab" aria-controls="w-bank-account" aria-selected="false">Bank Account</button>
                <button class="nav-link text-capitalize translate-html" data-i18n="crypto"  id="w-bank-account" data-toggle="tab" data-target="#wc-crypto" type="button" role="tab" aria-controls="w-crypto" aria-selected="false">Crypto</button>
              </div>
						</nav>
            <div class="tab-content tab-pills-content">
              <!-- withdraw: bank account -->
              <div class="tab-pane fade show active" id="wc-bank-account" role="tabpanel" aria-labelledby="wc-bank-account">
                <form action="/">
                  <div class="form-group">
                    <select name="bank" id="bank" class="form-control">
                      <option value="" class="translate-text" data-i18n="select-bank">Select Bank</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <select name="account_name" id="account_name" class="form-control">
                      <option value="" class="translate-text" data-i18n="bank-account-name">Bank Account Name</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <select name="account_number" id="account_number" class="form-control">
                      <option value="" class="translate-text" data-i18n="bank-account-number">Bank Account Number</option>
                    </select>
                  </div>
                  <div class="form-group amt-group">
                    <input type="text" name="amount" id="amount" class="form-control translate-placeholder" data-i18n="withdraw-amount" placeholder="Withdraw Amount" />
                    <span class="text-gold font-weight-bold">IDR</span>
                  </div>
                  <div class="form-group">
                    <div class="pl-4">
                      <p class="font15 font-italic text-gold font-weight-bold">
                        <span class="translate-text" data-i18n="available">Available</span>: 14,443.678 IDR
                      </p>
                      <p class="font15 font-italic text-gold font-weight-bold">
                        <span class="translate-text" data-i18n="transaction-limit">Transaction Limit</span> 100.000 - 100.000.000 IDR
                      </p>
                      <p class="font15 font-italic text-gold font-weight-bold mb-0">
                        <span class="translate-text" data-i18n="transaction-fee">Transaction Fee</span> 10.000IDR
                      </p>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="divider"></div>
                  </div>
                  <div class="form-group">
                    <div class="pl-4">
                      <p class="font15 text-white font-weight-bold mb-1 translate-text" data-i18n="amount-receivable">Amount Receivable</p>
                      <p class="font18 text-gold font-weight-bold mb-0">100.000.000</p>
                    </div>
                  </div>
                  <div class="d-flex align-items-center justify-content-center mt-4 mb-4">
                    <button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="widthraw-s">Withdraw</button>
                  </div>
                  <div class="text-center">
                    <p class="font-weight-bold font15 text-center translate-text" data-i18n="withdraw-note">Please ensure that you have filled in the bank details correctly.</p>
                  </div>
                </form>
              </div>

              <!-- withdraw: crypto -->
              <div class="tab-pane fade" id="wc-crypto" role="tabpanel" aria-labelledby="wc-crypto">
                <form action="/">
                  <div class="form-group">
                    <select name="currency" id="currency" class="form-control">
                      <option value="" class="translate-text" data-i18n="select-cryptocurrency" >Select Cryptocurrency</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <select name="network" id="network" class="form-control">
                      <option value="" class="translate-text" data-i18n="select-network">Select Network</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="text" name="crypto_address" id="crypto_address" class="form-control translate-placeholder" data-i18n="usdt-withdraw-address" placeholder="USDT Withdraw Address" />
                  </div>
                  <div class="form-group amt-group">
                    <input type="text" name="amount" id="amount" class="form-control translate-placeholder" data-i18n="withdraw-amount" placeholder="Withdraw Amount" />
                    <span class="text-gold font-weight-bold">USDT</span>
                  </div>
                  <div class="form-group">
                    <div class="pl-4">
                      <p class="font15 font-italic text-gold font-weight-bold">
                        <span class="translate-text" data-i18n="available">Available</span> :  1,888,30 USDT
                      </p>
                      <p class="font15 font-italic text-gold font-weight-bold">
                        <span class="translate-text" data-i18n="transaction-limit">Transaction Limit</span> 5000 USDT
                      </p>
                      <p class="font15 font-italic text-gold font-weight-bold">
                        <span class="translate-text" data-i18n="conversion-rate">Conversion Rate</span>  15.320 IDR
                      </p>
                      <p class="font15 font-italic text-gold font-weight-bold mb-0">
                        <span class="translate-text" data-i18n="transaction-fee">Transaction Fee</span>   5 USDT
                      </p>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="divider"></div>
                  </div>
                  <div class="form-group">
                    <div class="pl-4">
                      <p class="font15 text-white font-weight-bold mb-1 translate-text" data-i18n="amount-receivable">Amount Receivable</p>
                      <p class="font18 text-gold font-weight-bold mb-0">100.000.000</p>
                    </div>
                  </div>
                  <div class="d-flex align-items-center justify-content-center mt-4 mb-4">
                    <button type="button" class="btn btn-primary text-uppercase translate-html" data-i18n="widthraw-s">Withdraw</button>
                  </div>
                </form>
              </div>
              </div>
          </div>
        </div>
      </div>
    </div>

    <!-- login modal-  data-target="#loginModal"  -->
    <div class="modal fade" id="loginModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="auth-form text-center">
              <a href="/" class="logo mb-4 d-inline-block">
                <img src="./images/logo.png" alt="casino site">
              </a>
              <p class="font-weight-bold mb-4 text-gold text-uppercase translate-text" data-i18n="login">Login</p>
              <form class="px-2 mb-4">
                <div class="form-group">
                  <input type="text" class="form-control translate-placeholder" data-i18n="email" id="email" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control translate-placeholder" data-i18n="password" id="password" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-primary text-uppercase translate-text" data-i18n="login">Login</button>
              </form>
              <a href="reset-password.html" class="d-inline-block mb-4 text-gold link dynamic-link translate-text" data-i18n="forgot-password">Forgot Password</a>
              <p class="px-2">
                <span class="translate-text" data-i18n="no-account-label">Don’t have an account?</span>
                <a href="signup.html" class="text-gold link dynamic-link translate-text" data-i18n="signup">Sign Up</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- signup modal-  data-target="#signUpModal"  -->
    <div class="modal fade" id="signUpModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="auth-form text-center">
              <a href="/" class="logo mb-4 d-inline-block">
                <img src="./images/logo.png" alt="casino site">
              </a>
              <p class="font-weight-bold mb-4 text-gold text-uppercase translate-text" data-i18n="signup">Sign Up</p>
              <form class="px-2 mb-4">
                <div class="form-group">
                  <input type="text" class="form-control translate-placeholder" data-i18n="email" id="email" placeholder="Email">
                </div>
                <div class="form-group position-relative">
                  <input type="text" class="form-control translate-placeholder" data-i18n="username"  id="username" placeholder="Username">
                </div>
                <div class="form-group position-relative">
                  <input type="password" class="form-control translate-placeholder" data-i18n="password"  id="password" placeholder="Password">
                </div>
                <div class="form-group text-left">
                  <input type="text" class="form-control translate-placeholder" data-i18n="referral_code" id="referral_code" placeholder="Referral Code (Optional)">
                </div>
                <button type="submit" class="btn btn-primary text-uppercase translate-text" data-i18n="signup">Sign Up</button>
              </form>
              <p class="mb-4 px-2">
                  <span class="translate-text" data-i18n="signup-tnc-part1">By signing up I attest that I am at least 18 years old and have read the</span>
                  <a href="#" class="text-gold link dynamic-link translate-text" data-i18n="tnc">Terms of Service</a>
                  <span class="translate-text" data-i18n="signup-tnc-part2">and confirming that I am 18 years old and above.</span>
              </p>
            </div>
          </div>
          </div>
      </div>
    </div>

  </div>
</template>

<script>
module.exports = {

}
</script>