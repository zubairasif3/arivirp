<template>
  <div class="d-flex flex-column align-items-end">
    <div class="aside-box winner mb-3 py-4 px-3 bg-color-1b1b1b w-100">
      <p class="text-gold text-center font-weight-bold translate-text" data-i18n="latest-winners">Latest Winners</p>
      <div class="winner-list-slider">
        <div class="winner-list d-flex align-items-center justify-content-between mb-3">
          <div class="left d-flex align-items-center">
            <div class="img mr-2">
              <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
            </div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">Buu*** Namo*2021</p>
              <span class="d-block">Journey to the west</span>
            </div>
          </div>
          <div class="right d-flex align-items-start">
            <div class="img mr-1"><img src="./images/btc.png" alt=""></div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">0.088888888</p>
            </div>
          </div>
        </div>
        <div class="winner-list d-flex align-items-center justify-content-between mb-3">
          <div class="left d-flex align-items-center">
            <div class="img mr-2">
              <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
            </div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">Buu*** Namo*2021</p>
              <span class="d-block">Journey to the west</span>
            </div>
          </div>
          <div class="right d-flex align-items-start">
            <div class="img mr-1"><img src="./images/btc.png" alt=""></div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">0.088888888</p>
            </div>
          </div>
        </div>
        <div class="winner-list d-flex align-items-center justify-content-between mb-3">
          <div class="left d-flex align-items-center">
            <div class="img mr-2">
              <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
            </div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">Buu*** Namo*2021</p>
              <span class="d-block">Journey to the west</span>
            </div>
          </div>
          <div class="right d-flex align-items-start">
            <div class="img mr-1"><img src="./images/btc.png" alt=""></div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">0.088888888</p>
            </div>
          </div>
        </div>
        <div class="winner-list d-flex align-items-center justify-content-between mb-3">
          <div class="left d-flex align-items-center">
            <div class="img mr-2">
              <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
            </div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">Buu*** Namo*2021</p>
              <span class="d-block">Journey to the west</span>
            </div>
          </div>
          <div class="right d-flex align-items-start">
            <div class="img mr-1"><img src="./images/btc.png" alt=""></div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">0.088888888</p>
            </div>
          </div>
        </div>
        <div class="winner-list d-flex align-items-center justify-content-between mb-3">
          <div class="left d-flex align-items-center">
            <div class="img mr-2">
              <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
            </div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">Buu*** Namo*2021</p>
              <span class="d-block">Journey to the west</span>
            </div>
          </div>
          <div class="right d-flex align-items-start">
            <div class="img mr-1"><img src="./images/btc.png" alt=""></div>
            <div>
              <p class="text-gold mb-0 font-weight-bold">0.088888888</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="aside-box crypto mb-3 pt-4 pb-3 bg-color-1b1b1b w-100">
      <p class="text-gold text-center font-weight-bold translate-text" data-i18n="top-winners">Top Winners</p>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/btc.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">Bitcoin casino</p>
          <span class="text-uppercase d-block">BTC: $54418.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/eth.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">ETHEREUM CASINO</p>
          <span class="text-uppercase d-block">BETH: $35489.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/doge.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">DOGECOIN CASINO</p>
          <span class="text-uppercase d-block">DOGE: $23471.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/tether.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">Tether Casino</p>
          <span class="text-uppercase d-block">TET: $32597.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/bnb.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">BNB CASINO</p>
          <span class="text-uppercase d-block">BNB: $15896.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/xrp.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">XRP CASINO</p>
          <span class="text-uppercase d-block">XRP: $65378.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/usdc.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">USDC CASINO</p>
          <span class="text-uppercase d-block">USDC: $21896.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/busd.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">BUSD CASINO</p>
          <span class="text-uppercase d-block">BUSD: $15254.00</span>
        </div>
      </div>
      <div class="crypto-list d-flex align-items-center mb-2">
        <div class="img mr-3">
          <img src="./images/xmr.png" alt="">
        </div>
        <div>
          <p class="mb-0 text-uppercase font-weight-bold text-gold">XMR CASINO</p>
          <span class="text-uppercase d-block">XMR: $48712.00</span>
        </div>
      </div>
    </div>
    <div class="aside-box bitcoin-game-provider pt-4 pb-3 px-3 bg-color-1b1b1b w-100">
      <p class="text-gold text-center font-weight-bold translate-text translate-text" data-i18n="top-five--hottest-game-provider">Top 5 Hottest Game Providers </p>
      <a href="#" class="bitcoin-game-provider-list d-flex align-items-center mb-3">
        <div class="img overflow-hidden mr-3">
          <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
        </div>
        <p class="mb-0 font-weight-bold">Pragmatic Play with Bitcoun</p>
      </a>
      <a href="#" class="bitcoin-game-provider-list d-flex align-items-center mb-3">
        <div class="img overflow-hidden mr-3">
          <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
        </div>
        <p class="mb-0 font-weight-bold">Playtech with Bitcoin</p>
      </a>
      <a href="#" class="bitcoin-game-provider-list d-flex align-items-center mb-3">
        <div class="img overflow-hidden mr-3">
          <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
        </div>
        <p class="mb-0 font-weight-bold">PG Soft with Bitcoin</p>
      </a>
      <a href="#" class="bitcoin-game-provider-list d-flex align-items-center mb-3">
        <div class="img overflow-hidden mr-3">
          <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
        </div>
        <p class="mb-0 font-weight-bold">Joker  with Bitcoin</p>
      </a>
      <a href="#" class="bitcoin-game-provider-list d-flex align-items-center mb-3">
        <div class="img overflow-hidden mr-3">
          <img src="./images/bitcoin-game-sample.png" alt="bitcoin game provider">
        </div>
        <p class="mb-0 font-weight-bold">Habanero with Bitcoin</p>
      </a>
      <div class="text-center d-none">
        <button type="button" class="btn btn-link btn-modal-cta font-weight-normal">Show all <span class="text-gold">50 Providers</span></button>
      </div>
    </div>
  </div>
</template>

<script>
module.exports = {

}
</script>