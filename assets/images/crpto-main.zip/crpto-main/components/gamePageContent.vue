<template>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="games">
          <div class="d-flex align-items-center justify-content-between mb-3">
            <p class="text-uppercase text-gold font-weight-bold mb-0 translate-text" data-i18n="slots">Slots</p>
            <button type="button" class="btn btn-modal-cta text-gold translate-html" data-i18n="select-provider" data-toggle="modal" data-target="#providersModal">Select Provider</button>
          </div>
          <div class="game-list">
            <div class="row">
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                  <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                  <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
            </div>
          </div>
          <div class="game-list">
            <div class="row">
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="games">
          <div class="game-list">
            <div class="row">
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2">
                    <img src="../images/sample-game.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">LOST TREASURE</p>
                 <em class="d-none d-md-block">Evolution gaming</em>
                </div>
              </div>
            </div>
          </div>
          <div class="game-list">
            <div class="row">
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
              <div class="d-none d-md-block col-4 col-md-2 text-center game-list-item">
                <div class="animate-move-up">
                  <div class="img position-relative mb-2 game-tag game-tag-new">
                    <img src="../images/sample-game2.png" alt="game" class="img-fluid w-100 d-block m-0">
                  </div>
                  <p class="font-weight-bold">Poprocks</p>
                 <em class="d-none d-md-block">Playtech gaming</em>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row mb-4 d-none d-md-block">
      <div class="col-12">
        <nav aria-label="page navigation">
          <ul class="pagination pagination-lg justify-content-center">
            <li class="page-item">
              <a class="page-link" href="javascript:" tabindex="-1">
                <span aria-hidden="true">&lsaquo;</span>
              </a>
            </li>
            <li class="page-item active"><a class="page-link" href="javascript:">1</a></li>
            <li class="page-item"><a class="page-link" href="javascript:">2</a></li>
            <li class="page-item"><a class="page-link" href="javascript:">3</a></li>
            <li class="page-item">
              <a class="page-link" href="javascript:">
                <span aria-hidden="true">&rsaquo;</span>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</template>

<script>
module.exports = {

}
</script>